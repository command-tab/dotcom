<?php

	/* Fix these paths for your own install */
	require_once("amazon/AmazonSearch.php");
	require_once("dbconnect.php");
	
	$REPEAT_LIMIT = 5;
	
	
	// Get the current song
	$newtrack = trim(file_get_contents("track.html"));
	list($c_artist,$c_album,$c_title,$c_rating) = explode("&&&&&",$newtrack);

	
	// Get the last N songs
	$query = mysql_query("SELECT * FROM `tracks` ORDER BY `id` DESC LIMIT $REPEAT_LIMIT",$db);
	
	
	
	// loop through the last N and see if they match the current
	$total = mysql_num_rows($query);
	$gotit = false;
	for($i=0;$i<$total;$i++)
	{
		// compare each to the current infos
		$p = mysql_fetch_array($query,MYSQL_ASSOC);
		if(($c_artist == $p['artist']) && ($c_album == $p['album']) && ($c_title == $p['title']))
		{
			echo "<html><head><META HTTP-EQUIV=\"refresh\" content=\"1;URL=http://www.command-tab.com/\"><title>Cover Update</title></head><body>I have this song already.<br></body></html>";
			// have it - don't bother doing anything else
			$gotit = true;
		}
	}
	if($gotit == false)
	{
		// don't have it, so look up the info from Amazon
		$newsonginfo = getAmazonInfo($c_artist,$c_album,$c_title,"large");
		if($newsonginfo != false)
		{
			$now = date('r');
			$iurl = getiTunesLink($c_artist,$c_album,$c_title);
			$query = mysql_query("INSERT INTO `tracks` (`artist`,`title`,`album`,`time`,`rating`,`a_url`,`i_url`,`img`) VALUES('$c_artist','$c_title','$c_album','$now','$c_rating','$newsonginfo[0]','$iurl','$newsonginfo[1]')",$db);
			if($query)
			{
				echo "<html><head><META HTTP-EQUIV=\"refresh\" content=\"1;URL=http://www.command-tab.com/\"><title>Cover Update</title></head><body>Finished updating.<br></body></html>";
			}
		}
	}
	
	//echo "<html><head><META HTTP-EQUIV=\"refresh\" content=\"1;URL=http://www.command-tab.com/\"><title>Cover Update</title></head><body>Nothing to be done here.</body></html>";
	
	// Track Cleaner
	//
	// Keeps the maximum number of images and database entries down
	// to cleanLimit by requesting IDs, counting down the ordered list until
	// it reaches cleanLimit, selecting rows with IDs below that, removing the
	// image file, then removing the DB entry.
	
	$cleanLimit = 10;
	
	$query = mysql_query("SELECT `id` FROM `tracks` ORDER BY `id` DESC LIMIT $cleanLimit",$db);
	$total = mysql_num_rows($query);
	for($i=0;$i<$total;$i++)
	{
		$p = mysql_fetch_array($query,MYSQL_ASSOC);
		
		if($i==$total-1)
		{
			$cropat = $p['id'];
		}
	}
	// echo $cropat."<br><br>";
	$query = mysql_query("SELECT `id`,`img` FROM `tracks` WHERE `id` < $cropat ORDER BY `id` DESC",$db);
	$total = mysql_num_rows($query);
	for($i=0;$i<$total;$i++)
	{
		$p = mysql_fetch_array($query,MYSQL_ASSOC);
		if(file_exists($p['img']) && ($p['id'] < $cropat))
		{
			// remove the lower images
			unlink($p['img']);
			// remove entry from db
			$query = mysql_query("DELETE FROM `tracks` WHERE `id` = ".$p['id'],$db);
			if($query)
			{
				echo "<html><head><META HTTP-EQUIV=\"refresh\" content=\"1;URL=http://www.command-tab.com/\"><title>Cover Update</title></head><body>Removed ".$p['id']."<br></body></html>";
			}
		}
	}
	$tmpjpg = "wp-content/themes/command-tab/images/covers/temp.jpg";
	if(file_exists($tmpjpg))
	{
		unlink($tmpjpg);
	}
	
	//////////////////////
	
	
	function getiTunesLink($artist,$album,$title)
	{
		$link = "http://phobos.apple.com/WebObjects/MZSearch.woa/wa/advancedSearchResults?songTerm=".htmlentities($title)."&amp;albumTerm=".htmlentities($album)."&amp;artistTerm=".htmlentities($artist);
		
		return $link;
	}
	
	
	function getAmazonInfo($artist,$album,$title,$imgsize)
	{
		// create search object with dev token  !!!!! PUT YOUR AMAZON DEVELOPER CODE BELOW !!!!
		$AS = new AmazonSearch('XXXXXXXXXXXXXX');
		
		// get a list of albums by that artist
		$Results = $AS->DoArtistSearch($artist);
		
		$possibilities = array();
		
		foreach ($Results as $item)
		{
			// match the current album from mysql to one of the ones returned from amazon
			similar_text($item['ProductName'],$album,$percent);
			if(stristr($item['ProductName'],$album) != false || stristr($album, $item['ProductName']) != false || ($percent > 75))
			{
				$smImgURL = $item['ImageUrlSmall'];
				$mdImgURL = $item['ImageUrlMedium'];
				$lgImgURL = $item['ImageUrlLarge'];
				$produURL = $item['Url'];
				
				// use only the size we need; save some bandwidth
				if($imgsize == "small")
					{ $possibilities[] = array($produURL,$smImgURL); }
				
				if($imgsize == "medium")
					{ $possibilities[] = array($produURL,$mdImgURL); }
				
				if($imgsize == "large")
					{ $possibilities[] = array($produURL,$lgImgURL); }		
			}
		}
		
		$goodone = false;
		foreach($possibilities as $possibility)
		{
			// get the file, save as md5 of concat'ed string
			$filename = "wp-content/themes/command-tab/images/covers/temp.jpg";
			$mdfilename   = "wp-content/themes/command-tab/images/covers/".md5($artist.$album.$title).".jpg";
			$ch = file_get_contents($possibility[1]);
			$fp = fopen($filename, "w+");
			fwrite($fp,$ch);
			fclose($fp);
			

			// check the size if it exists
			if(file_exists($filename))
			{
				$imgfile = getimagesize($filename);
				if($imgfile)
				{
					$img_w = $imgfile[0];
					$img_h = $imgfile[1];
					
					// Check if it's even a usable size (bigger than 40x40)
					if(($img_w > 40) && ($img_h > 40) && file_exists($filename))
					{
						// Scale the image to 50x50
						list($width, $height) = getimagesize($filename);
						$new_width = 50;
						$new_height = 50;
						
						$image_p = imagecreatetruecolor($new_width, $new_height);
						$image = @imagecreatefromjpeg($filename);
						if($image != "") // if it fails for some reason
						{
							imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
						}
						else
						{
							if(file_exists($filename))
							{
								unlink($filename);
							}
							return false;
						}
						// Output
						imagejpeg($image_p, $mdfilename, 95);

						// Remove covers/temp.jpg
						if(file_exists($filename))
						{
							unlink($filename);
						}
						
						$goodone = true;
						break; // found a good one
					}
					else
					{
						// Remove covers/temp.jpg
						if(file_exists($filename))
						{
							unlink($filename);
						}
						return false;
					}
				}
			}
			else
			{
				// Remove covers/temp.jpg
				if(file_exists($filename))
				{
					unlink($filename);
				}
				// curl must have failed; abort now
				return false;
			}
		}
		
		// if the image is there and of the right size
		if($goodone == true)
		{
			// Remove covers/temp.jpg
			if(file_exists($filename))
			{
				unlink($filename);
			}
			// return an array with the amazon url and img $filename
			$answer = array($possibility[0],$mdfilename);
			return $answer;
		}
		else
		{
			// otherwise, forget this track
			// Remove covers/temp.jpg
			if(file_exists($filename))
			{
				unlink($filename);
			}
			return false;
		}
		
	}
?>