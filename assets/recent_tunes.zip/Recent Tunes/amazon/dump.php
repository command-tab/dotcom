<?php
	require_once("dbconnect.php");
	
	$query = mysql_query("DELETE FROM `tracks` WHERE 1",$db);
	if($query)
	{
		echo "Removed all.";
	}
	else
	{
		echo "No good.";
	}
?>