<?php

	$db = mysql_connect("localhost","USERNAME","PASSWORD") or die("");
	mysql_select_db("DATABASE") or die("");

?>