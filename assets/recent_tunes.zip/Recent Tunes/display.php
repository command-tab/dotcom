<?php
	if(!is_search() && !is_single() && !is_day() && !is_month())
	{
		$showmax = 5;
		require_once("amazon/dbconnect.php");
		$query = mysql_query("SELECT * FROM `tracks` ORDER BY `id` DESC LIMIT $showmax",$db);
	
		$total = mysql_num_rows($query);
		echo "<div id=\"recent_tunes\">Recent Tunes</div>";
		for($i=0;$i<$total;$i++)
		{
			$song = mysql_fetch_array($query,MYSQL_ASSOC);
			if(file_exists($song['img'])) // just in case something else broke..
			{
			
			?>
			
			<div id="tune">
				<div id="tune_top"></div>
				<div id="tune_middle">
					<div id="tune_img"><img src="http://www.command-tab.com/<?php echo $song['img']; ?>" title="<?php echo $song['artist']; ?> - <?php echo $song['album']; ?>" /></div>
					<div id="tune_info">
						<div id="tune_title"><?php echo $song['title']; ?></div>
						<div id="tune_artist"><?php echo $song['artist']; ?></div>
						<div id="tune_album"><?php echo $song['album']; ?></div>
					</div>
				</div>
				<div id="tune_bottom">
					<?php
						switch($song['rating'])
						{
							 case 0: { echo "<div id=\"tune_0star\" title=\"Unrated in iTunes\">"; break; }
							 case 1: { echo "<div id=\"tune_1star\" title=\"Rated 1 star in iTunes\">"; break; }
							 case 2: { echo "<div id=\"tune_2star\" title=\"Rated 2 stars in iTunes\">"; break; }
							 case 3: { echo "<div id=\"tune_3star\" title=\"Rated 3 stars in iTunes\">"; break; }
							 case 4: { echo "<div id=\"tune_4star\" title=\"Rated 4 stars in iTunes\">"; break; }
							 case 5: { echo "<div id=\"tune_5star\" title=\"Rated 5 stars in iTunes\">"; break; }
							default: { echo "<div id=\"tune_0star\" title=\"Unrated in iTunes\">"; break; }
						}
					
					?></div>
					<a href="<?php echo $song['i_url']; ?>" title="Search for <?php echo $song['title']; ?> on the iTunes Music Store"><div id="tune_i"></div></a>
					<a href="<?php echo $song['a_url']; ?>" title="Go to <?php echo $song['artist'].' - '.$song['album']; ?> on Amazon.com"><div id="tune_a"></div></a>
				</div>
			</div>
			
			<?php
			}
		}
	}
	
?>