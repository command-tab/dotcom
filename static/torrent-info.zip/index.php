<html>
	<head>
		<title>
			realtime torrent info
		</title>
	</head>
	<body>
		<form action="checkit.php" method="post" enctype="multipart/form-data">
			File: 
			<input type="file" name="file" size="30">
			<input type="submit" value="Upload Torrent">
		</form>
	</body>
</html>
